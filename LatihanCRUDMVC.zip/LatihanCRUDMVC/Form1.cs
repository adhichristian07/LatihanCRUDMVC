﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using LatihanCRUDMVC.Controller;

namespace LatihanCRUDMVC
{
    public partial class FrmMahasiswa: Form
    {
        //deklarasi objek controller
        private MahasiswaController _controller;

        //deklarasi private variabel/field _addData
        private bool _addData;

        //constructor
        public FrmMahasiswa()
        {
            InitializeComponent();
            InisialisasiListView();

            //membuat objek controller
            _controller = new MahasiswaController();

            //tampilkan data mahasiswa
            LoadDataMahasiswa();

            //atur ulang posisi tombol Simpan dan Batal
            //disamakan dengan posisi tombol Tambah dan Perbaiki
            btnSimpan.Location = btnTambah.Location;
            btnBatal.Location = btnPerbaiki.Location;
        }

        //format kolom listview
        private void InisialisasiListView()
        {
            lvwMahasiswa.View = System.Windows.Forms.View.Details;
            lvwMahasiswa.FullRowSelect = true;
            lvwMahasiswa.GridLines = true;

            lvwMahasiswa.Columns.Add("No.", 30, HorizontalAlignment.Center);
            lvwMahasiswa.Columns.Add("NPM", 91, HorizontalAlignment.Center);
            lvwMahasiswa.Columns.Add("Nama", 220, HorizontalAlignment.Left);
            lvwMahasiswa.Columns.Add("Alamat", 280, HorizontalAlignment.Left);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmMahasiswa_Load(object sender, EventArgs e)
        {

        }

        private void lvwMahasiswa_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void LoadDataMahasiswa()
        {
            //kosongkan data listview mahasiswa
            lvwMahasiswa.Items.Clear();

            //panggil method GetAll untuk mendapat semua data mahasiswa
            var list = _controller.GetAll();

            //lakukan perulangan untuk menampilkan data mahasiswa ke list view
            foreach (var mhs in list)
            {
                var noUrut = lvwMahasiswa.Items.Count + 1;

                var item = new ListViewItem(noUrut.ToString());
                item.SubItems.Add(mhs.npm);
                item.SubItems.Add(mhs.nama);
                item.SubItems.Add(mhs.alamat);

                lvwMahasiswa.Items.Add(item);
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            //status untuk operasi tambah atau perbaiki
            _addData - true; //operasi tambah data baru

            //kosongkan isian npm, nama dan alamat
            mskNPM.Clear();
            txtNama.Clear();
            txtAlamat.Clear();

            //fokus ke textbox npm
            mskNPM.Focus();

            //sembunyikan btnTambah, btnPerbaiki dan btnHapus
            btnTambah.Visible = false;
            btnPerbaiki.Visible = false;
            btnHapus.Visible = false;

            //tampilkan btnSimpan dan btnBatal
            btnSimpan.Visible = false;
            btnBatal.Visible = true;
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            //tampilkan btnTambah, btnPerbaiki dan btnHapus
            btnTambah.Visible = true;
            btnPerbaiki.Visible = true;
            btnHapus.Visible = true;

            //sembunyikan btnSimpan dan btnBatal
            btnSimpan.Visible = false;
        }

        private void btnPerbaiki_Click(object sender, EventArgs e)
        {
            //cek apakah data mahasiswa sudah dipilih
            if (lvwMahasiswa.SelectedItems.Count > 0)
            {
                _addData = false;

                //ambil index listview yang di pilih
                var index = lvwMahasiswa.SelectedIndices[0];

                var item = lvwMahasiswa.Items[index].Text;
                mskNPM.Text = item.SubItems[1].Text;
                txtNama.Text = item.SubItems[2].Text;
                txtAlamat.Text = item.SubItems[3].Text;

                mskNPM.Focus();

                //sembunyikan tombol tambah, perbaiki dan hapus
                btnTambah.Visible = false;
                btnPerbaiki.Visible = false;
                btnHapus.Visible = false;

                //tampilkan tombol simpan dan batal
                btnSimpan.Visible = true;
                btnBatal.Visible = true;
            }
            else //data belum dipilih
            {
                MessageBox.Show("Data mahasiswa belum dipilih !!!", "Peringatan",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
