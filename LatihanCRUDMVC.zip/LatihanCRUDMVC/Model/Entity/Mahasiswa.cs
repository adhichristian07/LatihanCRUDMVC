﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LatihanCRUDMVC.Model.Entity
{
    public class Mahasiswa
    {
        public string npm { get; set; }
        public string nama { get; set; }
        public string alamat { get; set; }
    }
}
